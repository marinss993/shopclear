<?php
    /*
    * @version      1.0.3 19.12.2017
    * @author       MAXXmarketing GmbH
    * @package      jshopping_checkout_back_button
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    */
    defined('_JEXEC') or die;
?>
<a href="<?php echo $link; ?>" class="a_checkout_back_button btn">
    <?php echo _JSHOP_BACK; ?>
</a>